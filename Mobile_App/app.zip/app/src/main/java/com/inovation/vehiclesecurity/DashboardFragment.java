package com.inovation.vehiclesecurity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class DashboardFragment extends Fragment {

    private TextView vehicleInfoTextView;

    public DashboardFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_dashboard, container, false);

        vehicleInfoTextView = rootView.findViewById(R.id.vehicleInfoTextView);

        // Ambil data kendaraan dan tampilkan
        vehicleInfoTextView.setText("Nama Kendaraan, Plat Nomor, dan informasi lainnya");

        return rootView;
    }
}
