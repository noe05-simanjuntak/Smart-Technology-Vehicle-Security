package com.inovation.vehiclesecurity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import android.view.View;
import android.widget.Button;

public class FragmentActivity extends AppCompatActivity {

    private Button changeFragmentButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);

        changeFragmentButton = findViewById(R.id.changeFragmentButton);

        // Menambahkan Fragment pertama secara default
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainer, new FragmentOne())
                    .commit();
        }

        // Tombol untuk mengganti Fragment
        changeFragmentButton.setOnClickListener(v -> {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            FragmentTwo fragment2 = new FragmentTwo();
            transaction.replace(R.id.fragmentContainer, fragment2);
            transaction.commit();
        });
    }
}
