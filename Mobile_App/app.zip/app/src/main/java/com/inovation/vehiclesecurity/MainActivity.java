package com.inovation.vehiclesecurity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button saveModeButton, securityModeButton, alarmToggleButton, dashboardButton, modeButton;
    private boolean isSaveModeOn = false;
    private boolean isSecurityModeOn = false;
    private boolean isAlarmOn = false;
    private MediaPlayer mediaPlayer;
    private TextView userInfoText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        saveModeButton = findViewById(R.id.saveModeButton);
        securityModeButton = findViewById(R.id.securityModeButton);
        alarmToggleButton = findViewById(R.id.alarmToggleButton);
        dashboardButton = findViewById(R.id.dashboardButton);
        modeButton = findViewById(R.id.modeButton);
        userInfoText = findViewById(R.id.userInfoText);

        // Ambil data dari SharedPreferences
        String email = getSharedPreferences("UserPreferences", MODE_PRIVATE)
                .getString("loggedInEmail", "");
        if (!email.isEmpty()) {
            String name = getSharedPreferences("UserPreferences", MODE_PRIVATE)
                    .getString(email + "_name", "User");
            String plate = getSharedPreferences("UserPreferences", MODE_PRIVATE)
                    .getString(email + "_vehiclePlate", "-");
            String type = getSharedPreferences("UserPreferences", MODE_PRIVATE)
                    .getString(email + "_vehicleType", "-");
            String brand = getSharedPreferences("UserPreferences", MODE_PRIVATE)
                    .getString(email + "_vehicleBrand", "-");
            String color = getSharedPreferences("UserPreferences", MODE_PRIVATE)
                    .getString(email + "_vehicleColor", "-");

            userInfoText.setText("Nama: " + name + "\nJenis: " + type + "\nMerk: " + brand + "\nWarna: " + color + "\nPlat: " + plate);
        }

        // Tombol Save Mode
        saveModeButton.setOnClickListener(v -> {
            isSaveModeOn = !isSaveModeOn;
            saveModeButton.setBackgroundColor(getResources().getColor(
                    isSaveModeOn ? R.color.teal_200 : R.color.darker_gray));
        });

        // Tombol Security Mode
        securityModeButton.setOnClickListener(v -> {
            isSecurityModeOn = !isSecurityModeOn;
            securityModeButton.setBackgroundColor(getResources().getColor(
                    isSecurityModeOn ? R.color.teal_700 : R.color.darker_gray));
        });

        // Alarm toggle
        mediaPlayer = MediaPlayer.create(this, R.raw.alarm);
        alarmToggleButton.setOnClickListener(v -> {
            if (isAlarmOn) {
                mediaPlayer.pause();
            } else {
                mediaPlayer.start();
            }
            isAlarmOn = !isAlarmOn;
        });

        // Tombol ke Dashboard (Fragment Features)
        dashboardButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MainFragmentActivity.class);
            startActivity(intent);
        });

        // Tombol ke Browser (atau Aplikasi Lain)
        modeButton.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW);
            browserIntent.setData(android.net.Uri.parse("https://www.google.com"));
            startActivity(browserIntent);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }
}
