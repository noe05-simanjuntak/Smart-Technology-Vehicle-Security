package com.inovation.vehiclesecurity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText nameInput, emailInput, passwordInput, vehiclePlateInput, colorInput;
    private Spinner vehicleTypeSpinner, brandSpinner;
    private Button registerButton;

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        nameInput = findViewById(R.id.nameInput);
        emailInput = findViewById(R.id.emailInputRegister);
        passwordInput = findViewById(R.id.passwordInputRegister);
        vehiclePlateInput = findViewById(R.id.vehiclePlateInputRegister);
        vehicleTypeSpinner = findViewById(R.id.vehicleTypeSpinner);
        brandSpinner = findViewById(R.id.brandSpinner);
        colorInput = findViewById(R.id.colorInput);
        registerButton = findViewById(R.id.registerButton);

        sharedPreferences = getSharedPreferences("UserPreferences", MODE_PRIVATE);

        registerButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String email = emailInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();
            String plate = vehiclePlateInput.getText().toString().trim();
            String vehicleType = vehicleTypeSpinner.getSelectedItem().toString();
            String brand = brandSpinner.getSelectedItem().toString();
            String color = colorInput.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || password.isEmpty() || plate.isEmpty() || color.isEmpty()) {
                Toast.makeText(this, "Semua data harus diisi!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Cek apakah user sudah ada
            if (sharedPreferences.contains(email + "_password")) {
                Toast.makeText(this, "Akun dengan email ini sudah terdaftar!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Simpan data berdasarkan email
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(email + "_name", name);
            editor.putString(email + "_password", password);
            editor.putString(email + "_vehiclePlate", plate);
            editor.putString(email + "_vehicleType", vehicleType);
            editor.putString(email + "_brand", brand);
            editor.putString(email + "_color", color);
            editor.apply();

            Toast.makeText(this, "Registrasi Berhasil! Silakan login.", Toast.LENGTH_SHORT).show();

            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            finish();
        });
    }
}
