package com.inovation.vehiclesecurity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private Button feature1Button, feature2Button, dashboardButton, modeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Inisialisasi tombol
        feature1Button = findViewById(R.id.feature1Button);
        feature2Button = findViewById(R.id.feature2Button);
        dashboardButton = findViewById(R.id.dashboardButton);
        modeButton = findViewById(R.id.modeButton);

        // Tombol untuk pindah ke MainFragmentActivity
        dashboardButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, MainFragmentActivity.class);
            startActivity(intent);
        });

        // Tombol untuk membuka halaman lain (Misalnya Website)
        modeButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("http://www.noe.com"));
            startActivity(intent);
        });
    }
}
